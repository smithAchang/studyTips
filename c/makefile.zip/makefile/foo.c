#include <stdlib.h>
#include <stdio.h>

extern int foo();

int foo()
{
   return 100;
}
